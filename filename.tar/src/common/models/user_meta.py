#coding=utf-8
import logging
import uuid
from blinker import signal

import models

class User_Meta(models.base.BaseThing):
    pass
